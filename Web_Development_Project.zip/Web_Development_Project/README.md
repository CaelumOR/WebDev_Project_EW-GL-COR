# WebDev_Project_EW-GL-COR
Project website: Selling high end cars for our our client John O'Reily
